var placeholder = '%voicechat_disabled%'

function placeholderCheck() {
	if (placeholder == '') {
		return '%voicechat_installed%';
	}
	else {
		return placeholder;
	}
}

placeholderCheck()