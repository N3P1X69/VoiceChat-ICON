var placeholder = '%voicechat_not_installed%'

function placeholderCheck() {
	if (placeholder == '') {
		return '';
	}
	else {
		return placeholder;
	}
}

placeholderCheck()